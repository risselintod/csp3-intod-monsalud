# Demo-App

Team Members
- Rissel Intod
- Jethro Monsalud


Regular User
  - email:   jamesDoe@mail.com (new admin/set-as-admin)
  - password: sample123 > sample1234admin (update-password)
Admin User**
  - email:   admin@mail.com
  - password: admin123

